import os, time

class Config:
    # setting for dataset and dataloader
    def __init__(self, dataset_path=None, batch_size=16):
        self.dataset_path = dataset_path or '/kaggle/input/evaluation-images/'
        if not os.path.exists(self.dataset_path):
            raise FileNotFoundError(f"{self.dataset_path} not found")
        
        self.batch_size = batch_size
        self.gpu_id = 0
        self.num_workers = 8

        # setting for training and optimization
        self.max_epoch = 50
        self.save_epoch = 1
        self.display_steps = 10
        self.score_level = 5

        self.use_weighted_loss = True
        self.use_attribute = True
        self.use_channel_attention = True
        self.use_saliency = True
        self.use_multipattern = True
        self.use_pattern_weight = True

        # AADB attributes
        self.attribute_types = ['RuleOfThirds', 'BalacingElements','DoF', 'Object', 'Symmetry', 'Repetition']
        self.num_attributes = len(self.attribute_types)
        self.attribute_weight = 0.1

        self.optimizer = 'adam'  # or sgd
        self.lr = 1e-4
        self.weight_decay = 5e-5
        self.momentum = 0.9

        # setting for cnn
        self.image_size = 224
        self.resnet_layers = 18
        self.dropout = 0.5
        self.pool_dropout = 0.5
        self.pattern_list = [1, 2, 3, 4, 5, 6, 7, 8]
        self.pattern_fuse = 'sum'

        # setting for testing
        self.test_epoch = 1

        # setting for experiments
        if len(self.pattern_list) == 1:
            self.exp_root = os.path.join(os.getcwd(), './experiments/single_pattern')
            self.prefix = f'pattern{self.pattern_list[0]}'
        else:
            self.exp_root = os.path.join(os.getcwd(), './experiments/')
            self.prefix = f'resnet{self.resnet_layers}'
            if self.use_multipattern:
                if self.use_pattern_weight and self.use_saliency:
                    self.prefix += '_samp'
                elif self.use_pattern_weight:
                    self.prefix += '_weighted_mpp'
                elif self.use_saliency:
                    self.prefix += '_saliency_mpp'
                else:
                    self.prefix += '_mpp'
            if self.use_attribute:
                if self.use_channel_attention:
                    self.prefix += '_aaff'
                else:
                    self.prefix += '_attr'
            if self.use_weighted_loss:
                self.prefix += '_wemd'

        self.exp_name = self.prefix
        self.exp_path = os.path.join(self.exp_root, self.prefix)

        while os.path.exists(self.exp_path):
            index = os.path.basename(self.exp_path).split(self.prefix)[-1]
            try:
                index = int(index) + 1
            except:
                index = 1
            self.exp_name = self.prefix + str(index)
            self.exp_path = os.path.join(self.exp_root, self.exp_name)

        print(f'Experiment name {os.path.basename(self.exp_path)} \n')
        self.checkpoint_dir = os.path.join(self.exp_path, 'checkpoints')
        self.log_dir = os.path.join(self.exp_path, 'logs')

    def create_path(self):
        print(f'Create experiment directory: {self.exp_path}')
        os.makedirs(self.exp_path)
        os.makedirs(self.checkpoint_dir)
        os.makedirs(self.log_dir)

if __name__ == '__main__':
    cfg = Config()
