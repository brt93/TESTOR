import os
import sys
import re
import argparse
from PIL import Image
import torchvision.transforms as transforms
import torch
from torch.utils.data import Dataset, DataLoader
import scipy.stats as stats
import numpy as np
from tqdm import tqdm
import torch.nn.functional as F

import tensorflow as tf
from tensorflow.keras.applications.resnet50 import ResNet50, preprocess_input
from tensorflow.keras.preprocessing.image import load_img, img_to_array
import cv2

sys.path.append('/kaggle/input/sampnet')
from samp_net import SAMPNet
sys.path.append('/kaggle/input/sampnet/')
from config import Config

# dist2ave function: Converts predicted distribution to average score
def dist2ave(pred_dist):
    pred_score = torch.sum(pred_dist * torch.Tensor(range(1, 6)).to(pred_dist.device), dim=-1, keepdim=True)
    return pred_score

def extract_number(filename):
    match = re.search(r'shot_(\d+)', filename)
    return int(match.group(1)) if match else -1

class CustomImageDataset(Dataset):
    def __init__(self, image_dir, transform=None, use_saliency=True):
        self.image_dir = image_dir
        # Sort filenames based on the number after 'shot_'
        self.image_filenames = sorted(
            [f for f in os.listdir(image_dir) if f.endswith(('png', 'jpg', 'jpeg'))],
            key=extract_number
        ) 
        self.transform = transform
        self.use_saliency = use_saliency

        # Debug: Print all image filenames
        print(f"Total images found in {image_dir}: {len(self.image_filenames)}")
        for idx, fname in enumerate(self.image_filenames):
            print(f"Image {idx+1}: {fname}")

    def generate_saliency_map(self, img_path):
        # Load the image
        img = load_img(img_path, target_size=(224, 224))
        img_array = img_to_array(img)
        img_array = np.expand_dims(img_array, axis=0)
        img_array = preprocess_input(img_array)

        # Load pre-trained ResNet50 model
        model = ResNet50(weights='imagenet')

        # Get the model prediction
        preds = model.predict(img_array)
        class_idx = np.argmax(preds[0])

        # Create a model that maps the input image to the activations of the last conv layer as well as the output predictions
        last_conv_layer = model.get_layer('conv5_block3_out')
        grad_model = tf.keras.models.Model(inputs=model.input, outputs=[last_conv_layer.output, model.output])

        # Compute the gradient of the top predicted class
        with tf.GradientTape() as tape:
            conv_outputs, predictions = grad_model(img_array)
            loss = predictions[:, class_idx]

        grads = tape.gradient(loss, conv_outputs)
        pooled_grads = tf.reduce_mean(grads, axis=(0, 1, 2))

        # Convert conv_outputs tensor to numpy array
        conv_outputs = conv_outputs[0].numpy()
        pooled_grads = pooled_grads.numpy()

        # Multiply each channel by how important it is for the predicted class
        for i in range(pooled_grads.shape[-1]):
            conv_outputs[:, :, i] *= pooled_grads[i]

        # Generate heatmap
        heatmap = np.mean(conv_outputs, axis=-1)
        heatmap = np.maximum(heatmap, 0)
        heatmap /= np.max(heatmap)

        # Resize heatmap to match the model's input
        heatmap_resized = cv2.resize(heatmap, (224, 224))

        # Convert heatmap to a PyTorch tensor and add channel dimension
        saliency_map = torch.tensor(heatmap_resized).unsqueeze(0).unsqueeze(0)
        
        saliency_map = saliency_map.mean(dim=1, keepdim=True)


        return saliency_map

    def __len__(self):
        return len(self.image_filenames)

    def __getitem__(self, idx):
        img_path = os.path.join(self.image_dir, self.image_filenames[idx])
        #image = Image.open(img_path).convert("RGB")
        try:
            image = Image.open(img_path).convert("RGB")
        except Exception as e:
            print(f"Error loading image {img_path}: {e}")
            return None, None
        
        # Generate saliency map only if use_saliency is True
        if self.use_saliency:
            try:
                saliency_map = self.generate_saliency_map(img_path)
            except Exception as e:
                print(f"Error generating saliency map for {img_path}: {e}")
                saliency_map = None
        else:
            saliency_map = None
        
        if self.transform:
            image = self.transform(image)

        return image, saliency_map
# Evaluation function for custom images
def evaluation_on_custom_data(model, image_dir, cfg):
    model.eval()
    device = next(model.parameters()).device

    #accumulate scores for average computation
    total_score = 0.0
    num_images = 0

    
    # Load custom images using your CustomImageDataset
    testdataset = CustomImageDataset(image_dir, transform=transforms.Compose([
        transforms.Resize((cfg.image_size, cfg.image_size)),
        transforms.ToTensor(),
    ]), use_saliency=cfg.use_saliency)
    
    
    testloader = DataLoader(testdataset, batch_size=cfg.batch_size, shuffle=False, num_workers=cfg.num_workers)
    
    print('Evaluation on custom images...')
    with torch.no_grad():
        
        for batch_idx, (im, saliency_map) in enumerate(tqdm(testloader)):  # Load both the image and the saliency map
            print(f"Processing batch {batch_idx + 1}/{len(testloader)} with {len(im)} images")

            image = im.to(device)

            if saliency_map is None:
                print("Saliency map is None")
                
            if saliency_map is not None:
                saliency_map = saliency_map.to(device)

                if saliency_map.dim() == 5 and saliency_map.shape[2] == 1:
                    # Remove the extra dimension
                    saliency_map = saliency_map.squeeze(2) 
                
                # Ensure saliency map has 1 channel for greyscale
                if saliency_map.shape[1] != 1:
                   saliency_map = saliency_map.mean(dim=1, keepdim=True)
                   
                weight, atts, output = model(image, saliency_map)
            else:
                # Call model with only the image
                weight, atts, output = model(image, None)
                
            pred_score = dist2ave(output)  # Convert distribution to score

            # Assuming pred_score is a tensor with shape [batch_size, 1]
            total_score += pred_score.sum().item()  # Sum of scores for the current batch
            num_images += pred_score.size(0)  # Number of images in the current batch

            
            # Print the predicted score for each image
            print(f'Predicted Score: {pred_score}')

     # Calculate and print the average score
    average_score = total_score / num_images if num_images > 0 else 0
    print(f'\nAverage Quality Composition Score: {average_score:.4f}')

    print('Evaluation completed.')
    

if __name__ == '__main__':

    parser = argparse.ArgumentParser(description="Run evaluation on custom images with SAMPNet.")
    
    # Add the command-line argument for custom image directory
    parser.add_argument('--custom_image_dir', type=str, required=True, 
                        help='Path to the directory containing custom images for evaluation')
    
    # Optional argument for batch size
    parser.add_argument('--batch_size', type=int, default=16, 
                        help='Batch size for evaluation')
    
    # Parse the arguments
    args = parser.parse_args()

    #cfg = Config()
    cfg = Config(dataset_path=args.custom_image_dir, batch_size=args.batch_size)
    device = torch.device('cuda:{}'.format(cfg.gpu_id))
    model = SAMPNet(cfg, pretrained=False).to(device)

    # Load the pre-trained weights
    weight_file = '/kaggle/input/sampnet/samp_net.pth'
    model.load_state_dict(torch.load(weight_file))

    # Evaluate custom images
    evaluation_on_custom_data(model, args.custom_image_dir, cfg)